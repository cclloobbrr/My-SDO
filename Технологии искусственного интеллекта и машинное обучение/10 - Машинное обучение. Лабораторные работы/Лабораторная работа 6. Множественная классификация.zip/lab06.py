import numpy as np
import scipy.optimize as op
import matplotlib.pyplot as plt  


def main():
    num_labels = 10  # 10 классов, от 0 до 9

    ## 1. Загрузка данных
    with open('ex3data1.npy', 'rb') as f:
        X = np.load(f)  # чтение матрицы X из бинарного файла формата numpy 
        y = np.load(f)  # чтение вектора y из бинарного файла формата numpy
    print('Отображение обучающего набора данных')
    # Выберем из обучающего набора 100 случайных изображений и покажем их
    indices = np.random.permutation(X.shape[0])[:100]  
    selected = X[indices, :]
    display_data(selected, 10, 10, 20, 20)
    input('Перейдите в терминал и нажмите Enter для продолжения...')

    # Удалите следующую строку для продолжения работы
    return

    ## 2. Регуляризованная логистическая регрессия
    theta_t = np.array([-2, -1, 1, 2])
    X_t = np.hstack((np.ones(5).reshape(5, 1), np.arange(1, 16).reshape(3, 5).T / 10))
    y_t = (np.array([1, 0, 1, 0, 1]) >= 0.5)
    lamb_t = 3
    cost_t = cost_function(theta_t, X_t, y_t, lamb_t)
    grad_t = gradient_function(theta_t, X_t, y_t, lamb_t)
    print('\nФункция стоимости:', cost_t)
    print('Ожидаемое значение (приблизительно): 2.534819')
    print('Градиент:', grad_t)
    print('Ожидаемый градиент (приблизительно): [ 0.146561  -0.548558  0.724722  1.398003 ]')
    input('Перейдите в терминал и нажмите Enter для продолжения...')

    # Удалите следующую строку для продолжения работы
    return

    ## 3. Обучение "один-против-всех"
    print('\nОбучение логистической регрессии "один-против-всех"')
    lamb = 0.1
    all_theta = one_vs_all(X, y, lamb, num_labels)
    input('Перейдите в терминал и нажмите Enter для продолжения...')

    # Удалите следующую строку для продолжения работы
    return

    ## 4. Предсказание "один-против-всех"
    p = predict_one_vs_all(X, all_theta)
    e = np.mean((p == y)) * 100
    print('\nТочность на обучающем наборе, в %:', e)
    print('Ожидаемая точность: 95% и выше')


# Логистическая фукнция
def sigmoid(z):
    g = np.zeros(z.shape)
    # ------ добавьте свой код --------
    # ...  
    # ---------------------------------
    return g


# Функция стоимости регуляризованной логистической регрессии
def cost_function(theta, X, y, lamb):
    J = 0
    # ------ добавьте свой код --------
    # ...
    # ---------------------------------
    return J


# Функция вычисления градиента регуляризованной логистической регрессии
def gradient_function(theta, X, y, lamb):
    dth = np.zeros(theta.shape)
    # ------ добавьте свой код --------
    # ...
    # ---------------------------------
    return dth.flatten()


# Обучение моделей логистической регрессии для всех классов
def one_vs_all(X, y, lamb, num_labels):
    [m, n] = X.shape
    all_theta = np.zeros((num_labels, n + 1))
    # ------ добавьте свой код --------
    # ...
    # ---------------------------------
    return all_theta


# Функция предсказания значений по всем классам
def predict_one_vs_all(X, all_theta):
    m = X.shape[0]
    num_labels = all_theta.shape[0]
    p = np.zeros(m, dtype=int)
    # ------ добавьте свой код --------
    # ...
    # ---------------------------------
    return p


# Отображение обучающего набора
def display_data(X, width, height, el_width, el_height):
    plt.figure()
    for i in range(height):
        for j in range(width):
            el = X[i * height + j].reshape(el_height, el_width).T
            row = np.hstack((row, el)) if j > 0 else el
        fig = np.vstack((fig, row)) if i > 0 else row
    plt.imshow(fig)
    plt.show()


if __name__ == '__main__':
    plt.ion()
    main()
    input('Перейдите в терминал и нажмите Enter для завершения')
    plt.clf()
